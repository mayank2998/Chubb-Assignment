import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-weekly-news',
  templateUrl: './weekly-news.component.html',
  styleUrls: ['./weekly-news.component.css']
})
export class WeeklyNewsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
