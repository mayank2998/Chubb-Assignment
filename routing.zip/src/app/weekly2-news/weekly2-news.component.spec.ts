import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Weekly2NewsComponent } from './weekly2-news.component';

describe('Weekly2NewsComponent', () => {
  let component: Weekly2NewsComponent;
  let fixture: ComponentFixture<Weekly2NewsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Weekly2NewsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Weekly2NewsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
