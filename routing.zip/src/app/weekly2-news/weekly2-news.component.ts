import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-weekly2-news',
  templateUrl: './weekly2-news.component.html',
  styleUrls: ['./weekly2-news.component.css']
})
export class Weekly2NewsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
