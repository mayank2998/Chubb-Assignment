import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-youtube-section',
  templateUrl: './youtube-section.component.html',
  styleUrls: ['./youtube-section.component.css']
})
export class YoutubeSectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
