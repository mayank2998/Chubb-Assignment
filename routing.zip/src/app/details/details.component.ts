import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
//import { time } from 'console';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

  id:number = 0;

  detailsText = [
    {
      ids : 1,
      image : "assets/img/trending/right1.jpg",
      buttonText : "Concert",
      linkText : "Welcome To The Best Model Winner Contest" 
    },
    {
      ids : 2,
      image : "assets/img/trending/right2.jpg",
      buttonText : "sea beach",
      linkText : "Welcome To The Best Model Winner Contest" 
    },
    {
      ids : 3,
      image : "assets/img/trending/right3.jpg",
      buttonText : "Bike Show",
      linkText : "Welcome To The Best Model Winner Contest" 
    },
    {
      ids : 4,
      image : "assets/img/trending/right4.jpg",
      buttonText : "sea beach",
      linkText : "Welcome To The Best Model Winner Contest" 
    }
  ]

  constructor(private activeRoute:ActivatedRoute) { 
    this.id = this.activeRoute.snapshot.params.id;
    
  }

  ngOnInit(): void {
   

    this.activeRoute.params.subscribe(routeParams => {
      this.id=routeParams.id;
      console.log("route param",routeParams.id);
    });
    console.log("-");
  }

}
