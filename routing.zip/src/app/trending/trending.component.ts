import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trending',
  templateUrl: './trending.component.html',
  styleUrls: ['./trending.component.css']
})
export class TrendingComponent implements OnInit {

  cards = [
    {
      id : 0,
      image : "assets/img/trending/right1.jpg",
      buttonText : "Concert",
      linkText : "Welcome To The Best Model Winner Contest" 
    },
    {
      id : 1,
      image : "assets/img/trending/right2.jpg",
      buttonText : "sea beach",
      linkText : "Welcome To The Best Model Winner Contest" 
    },
    {
      id : 2,
      image : "assets/img/trending/right3.jpg",
      buttonText : "Bike Show",
      linkText : "Welcome To The Best Model Winner Contest" 
    },
    {
      id : 3,
      image : "assets/img/trending/right4.jpg",
      buttonText : "sea beach",
      linkText : "Welcome To The Best Model Winner Contest" 
    }
  ]

  constructor() { }

  ngOnInit(): void {
  }

}
